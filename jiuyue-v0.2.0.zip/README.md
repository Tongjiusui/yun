# jiuyue

A modding framework and simulation suite for **Age of History II: Definitive Edition**.

> ## ⚠️ Test version. Most of what you would want is not in it yet.
>
> **Please read this before installing anything.**
>
> **What works.** The framework loads, the simulation runs every turn, the three
> panels draw in the game's own top bar, and 437 assertions pass without
> launching the game. The economy and the army really do move numbers around.
>
> **What does not work.** *Nothing decides anything.* Territory does not change
> hands. Divisions have no map position. There is no trade between markets. The
> simulation builds what it thinks is missing and the army fights on its own,
> and **you cannot tell either of them to do otherwise** — there is no interface
> for the player at all.
>
> **There is no new game here yet.** There is a floor, and instruments standing
> on it. Everything is subject to change, and things will break.
>
> **0.x means pre-release.** By the usual convention nothing below 1.0 is
> finished, and this is not close to 1.0.

Written from scratch against the vanilla game. No third-party mod framework is
needed to build it or to run it, and the build refuses to compile if one creeps
into the output.

---

## What this is

Four things that work together:

| | What it does |
|---|---|
| **jiuyue** | The mixin framework. Hooks into the game's own classes at load time, in memory. Never replaces a file on disk. |
| **Atlas** | The simulation. A Victoria-3-style economy and a Hearts-of-Iron-4-style military, running alongside the game and writing its results back. |
| **mapack** | A packing tool. Turns the map's twelve thousand small files into one. |
| **steamfix** | A startup fix for a crash in the game's own Steam initialisation. |

---

## Features

### Economy (Victoria 3 style)

- **16 goods** across three tiers: raw (grain, livestock, wood, coal, iron, oil),
  industrial (fabric, lumber, steel, tools, machinery), and consumer (clothes,
  furniture, groceries, liquor, luxury).
- **38 production methods.** A steel mill with no iron produces no steel. Inputs
  limit output, which the base game has no concept of.
- **Three population strata** with their own consumption baskets. Pops that cannot
  buy what they need lose wealth, and poorer pops buy less.
- **Terrain endowments.** The game stores no resource data, so coal, iron, oil and
  farmland are derived from each province's terrain type.
- **A construction queue** the simulation decides for itself: it looks at what is
  short and builds accordingly.
- **Markets** with prices that move with supply and demand.

### Military (Hearts of Iron 4 style)

- **Five division types** with their own manpower, equipment and supply needs.
- **Equipment is consumed**, not assumed: raising a division costs tools, and
  keeping one costs food every turn.
- **Readiness**, which falls when supply is short. An army that is not fed does not
  fight worse — it stops fighting.
- **Combat resolution** on land borders, with mutual proportional attrition.
- **The army eats before the population does.** That is a deliberate choice, and it
  is why a large army visibly lowers living standards instead of quietly being
  absorbed.

### Interface

- **Three system panels** in the game's own top bar: Economy, Military, Society.
  Built from the game's own Menu, Text and Button classes, so they match.
- **Event counters**, configurable in a text file, usable from the game's own event
  editor.
- **A loading screen** in the HOI4 style.
- **Voice lines** for army sounds, with as many variants as you care to record.

---

## Install

### Requirements

- Age of History II: Definitive Edition
- The game's bundled Java 8 runtime (already in the game folder under `jre`)
- Steam running, or the game crashes in its own Steam code before anything loads

### Steps

1. Copy these into your game folder:
   ```
   jiuyue-agent.jar
   mods/Atlas/plugins/atlas.jar
   mods/Atlas/plugins/steamfix.jar
   ```

2. Launch the game with the agent:

   **Windows (a .bat file in the game folder):**
   ```bat
   @echo off
   cd /d "%~dp0"
   jre\bin\java.exe -javaagent:jiuyue-agent.jar=mods\Atlas\plugins -jar game.jar
   ```

   Steam must be running. If it is not, the game will close immediately —
   that is the bug `steamfix` works around, and it is in the game, not here.

3. On first run, configuration files appear in `mods/Atlas/`:

   | File | What it controls |
   |---|---|
   | `counters.txt` | The counters your events can test and change |
   | `voice.txt` | Which sound files replace which game sounds |
   | `loading.txt` | The lines shown on the loading screen |
   | `hud.txt` | Where the on-screen panel sits |
   | `packs.txt` | Which map packs to read from |

---

## Command-line switches

| Switch | Default | Effect |
|---|---|---|
| `-Datlas.writeBack=1` | off | Let the simulation change game buildings |
| `-Datlas.log=0` | info | Verbose logging |
| `-Datlas.loading=0` | on | Use the game's own loading screen |
| `-Datlas.voice=0` | on | Use the game's own army sounds |
| `-Datlas.packs=0` | on | Ignore map packs |
| `-Datlas.counters=0` | on | Turn counters off |
| `-Datlas.hud=1` | off | Show a separate floating panel |

**Write-back is off by default, and that is deliberate.** Everything else can be
undone by deleting a file. Writing into the game's own province data cannot: a
wrong write is not a bug you roll back, it is a save file you have corrupted. When
it is on, only nine building counters are ever touched, every write is read back
and verified, and refusals keep their credit rather than losing it.

---

## Building from source

See [docs/BUILDING.md](docs/BUILDING.md).

Short version: `powershell -ExecutionPolicy Bypass -File atlas\build.ps1`

---

## Testing

**437 assertions**, and every one of them runs without launching the game:

| Suite | Assertions |
|---|---:|
| Atlas simulation (13 suites) | 392 |
| The packing tool | 19 |
| The framework | 26 |

`atlas\build.ps1` runs all of them as its fourth step and stops on the first
failure.

The kernel has **zero imports from the game**, and the build enforces that by
searching the compiled bytecode rather than trusting the source. That is not a
style preference -- it is the only reason any of this is testable. A simulation
you can observe only through log lines is a simulation you cannot debug.

---

## Status

**Test version. Expect it to change, move and break.**

The parts that exist are finished carefully: the kernel is exact, the tests are
real, and the write-back path is fenced off because a wrong write into a save
file is not a bug you roll back. The parts that do not exist simply do not exist,
and no effort went into making them look like they do.

### Works

- The mixin framework. Hooks into the loaded game; rewrites no file on disk.
- The economy: 16 goods, 38 production methods, three population strata, terrain
  endowments, prices, a construction queue, food riots.
- The military: five division types, equipment consumption, readiness, combat on
  land borders, attrition.
- Three panels in the game's own top bar: Economy, Military, Society.
- Configurable counters, usable from the game's event editor.
- Voice lines, map packs, an HOI4-style loading screen.
- 437 assertions, none of which need the game running.

### Does not work yet

- **No decisions.** Territory does not change hands. Combat destroys divisions
  and readiness, then stops.
- **No divisions on the map.** The army list in the save file could not be read,
  so an army is a number rather than a thing with a position.
- **No trade between markets.** Each country's market is its own island.
- **No player interface for the simulation.** It builds and it fights, and you
  watch.
- **No balance.** The numbers have not been tuned against a real campaign,
  because there is not yet a campaign to tune them against.

### What that adds up to

If you install this expecting a new game, you will be disappointed. If you
install it to watch a simulation run underneath the one you already have, and to
read code that says what it does, it is worth the ten minutes.

---

## Licence

**GNU General Public License v3.0 or later.** See [LICENSE](LICENSE).

In short: you may use, change and redistribute this, including commercially, but
**anything you build from it must also be GPLv3 and must ship its source.** It
cannot be taken closed-source.

That is a deliberate choice. This project exists because a previous one could not
be inspected or extended freely, and the licence is meant to keep that from
happening here.

Every source file carries the standard notice, as the licence asks.
