# Building from source

## What you need

- **JDK 8 or newer.** The output must be class file version 52, because the game
  ships its own Java 8 runtime. Building on a newer JDK is fine as long as
  `--release 8` is passed, which every build script here does.
- **The game itself.** `atlas\libs\game.jar` is a copy of the installed
  `game.jar`, used only as a compile-time classpath. It is not redistributed here.
- **PowerShell.** The build scripts are `.ps1`.

Nothing else. No Gradle, no Maven, no dependency downloads.

---

## Build order

The pieces depend on each other in one direction:

```
jiuyue  ──>  atlas  ──>  release
   └────>  steamfix
mapack  (standalone)
```

### 1. The framework

```powershell
powershell -ExecutionPolicy Bypass -File jiuyue\build.ps1
```

Produces `jiuyue\build\jiuyue-agent.jar` and `jiuyue\build\jiuyue-mixin-api.jar`.

The build **deletes `jiuyue\build` first**. If you have copied the agent jar
anywhere, that copy is now stale — and a stale agent is the worst kind of bug
here, because it fails inside the JVM's class transformer where the only symptom
is a `NoSuchMethodError` at the call site.

### 2. The plugin

```powershell
powershell -ExecutionPolicy Bypass -File atlas\build.ps1
```

Five steps, and it stops at the first one that fails:

1. **Check `libs\game.jar` against the installed game.** If they differ, the
   classpath you are compiling against is not the game you are running.
2. **Compile** all 75 source files with `--release 8`.
3. **Check the bytecode version.** Every class must be 52.0. A single class built
   for a newer JVM makes the game fail to start with an unhelpful message.
4. **Check dependencies.** The kernel packages must not import anything from
   `age.of.civilizations2`. This is enforced mechanically because it is the one
   invariant that makes the simulation testable.
5. **Run the tests**, then jar.

### 3. The packer

```powershell
cd mapack
javac --release 8 -encoding UTF-8 -d build\classes (Get-ChildItem src -Recurse -Filter *.java).FullName
```

---

## Running the tests

The build script runs all of them. To run one on its own:

```powershell
& jre\bin\java.exe -cp "build\classes;build\test" AtlasKernelTest
```

**Run them from their own directory.** `JiuyueTest` walks a relative path to find
its fixtures; run it from the repository root and it scans the wrong tree and
fails seven assertions that are not about your change.

---

## Layout

```
jiuyue/          the mixin framework
  src/main/java/jiuyue/agent/        the agent and transformer
  src/main/java/jiuyue/mixin/        the annotations
  test/                              the framework's own tests

atlas/           the plugin
  src/main/java/jiuyue/atlas/
    kernel/      the simulation. ZERO game imports.
    adapter/     the only place the kernel touches the game
    mixin/       the hooks into game classes
    hud/         the on-screen panels
    counter/     the configurable counters
    loading/     the loading screen
    voice/       army voice lines
    persist/     the sidecar save file
  test/          every test, all runnable without the game

mapack/          the packing tool
steamfix/        the startup fix
```

---

## Adding a hook

A mixin looks like this:

```java
@Mixin(target = "age.of.civilizations2.jakowski.lukasz.MenuManager")
public final class MixinMenuManager {

    @Inject(method = "drawMM", desc = "(Lcom/badlogic/gdx/graphics/g2d/SpriteBatch;)V",
            at = At.RETURN)
    public static void atlas_draw(CallbackInfo ci) {
        // runs after the game has drawn its menus
    }
}
```

Pass the target instance as the **first parameter** and it is supplied
automatically — the annotation processor decides whether to inject `ALOAD 0` by
looking at that parameter's descriptor. There is no flag to set.

**Cancellable injection is void-only.** A non-void target is refused and logged
rather than half-supported.

**Find the descriptors with `javap`, not by guessing.** A wrong descriptor does
not fail loudly; it produces a mixin that simply never runs.
