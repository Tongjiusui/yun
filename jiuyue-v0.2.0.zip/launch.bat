@echo off
cd /d "%~dp0"
rem Steam must be running, or the game exits before anything loads.
jre\bin\java.exe -javaagent:jiuyue-agent.jar=mods\Atlas\plugins -jar game.jar